# Airline Reservation System

A modern web-based airline reservation system built with Flask and SQLAlchemy.

## Features

- User registration and authentication
- Browse available flights
- Book flights with seat assignment
- View booking history
- Responsive design using Bootstrap

## Installation

1. Create a virtual environment:
```bash
python -m venv venv
venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python flyhigh.py
```

4. Open your browser and navigate to `http://localhost:5000`

## Usage

1. Register a new account or login with existing credentials
2. Browse available flights on the home page
3. Click "Book Now" on any flight to make a reservation
4. View your bookings in the "My Bookings" section

## Database

The application uses SQLite as the database. The database file (`airline.db`) will be created automatically when you run the application for the first time.
