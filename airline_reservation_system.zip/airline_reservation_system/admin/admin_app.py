from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
import os
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../flyhigh.db'  # Use the same DB as main app
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Import models from main app
from datetime import datetime

class Flight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    flight_number = db.Column(db.String(20), unique=True, nullable=False)
    origin = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.DateTime, nullable=False)
    duration = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    seats = db.relationship('Seat', backref='flight', lazy=True)
    services = db.relationship('Service', backref='flight', lazy=True)

class Seat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    seat_number = db.Column(db.String(10), nullable=False)
    is_booked = db.Column(db.Boolean, default=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'))

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)

# Simple admin credential (for demo)
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials', 'danger')
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('admin_login'))

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    return render_template('admin_dashboard.html')

@app.route('/admin/flights')
def admin_flights():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    flights = Flight.query.all()
    return render_template('admin_flights.html', flights=flights)

@app.route('/admin/flights/add', methods=['GET', 'POST'])
def add_flight():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    if request.method == 'POST':
        name = request.form['name']
        flight_number = request.form['flight_number']
        origin = request.form['origin']
        destination = request.form['destination']
        departure_time = request.form['departure_time']
        duration = request.form['duration']
        price = request.form['price']
        flight = Flight(name=name, flight_number=flight_number, origin=origin, destination=destination,
                        departure_time=departure_time, duration=duration, price=price)
        db.session.add(flight)
        db.session.commit()
        flash('Flight added successfully!', 'success')
        return redirect(url_for('admin_flights'))
    return render_template('admin_add_flight.html')

@app.route('/admin/flights/<int:flight_id>/edit', methods=['GET', 'POST'])
def edit_flight(flight_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    flight = Flight.query.get_or_404(flight_id)
    if request.method == 'POST':
        flight.name = request.form['name']
        flight.flight_number = request.form['flight_number']
        flight.origin = request.form['origin']
        flight.destination = request.form['destination']
        flight.departure_time = request.form['departure_time']
        flight.duration = request.form['duration']
        flight.price = request.form['price']
        db.session.commit()
        flash('Flight updated successfully!', 'success')
        return redirect(url_for('admin_flights'))
    return render_template('admin_edit_flight.html', flight=flight)

@app.route('/admin/flights/<int:flight_id>/seats', methods=['GET', 'POST'])
def manage_seats(flight_id):
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login'))
    flight = Flight.query.get_or_404(flight_id)
    if request.method == 'POST':
        seat_number = request.form['seat_number']
        is_booked = request.form.get('is_booked') == 'on'
        seat = Seat(seat_number=seat_number, flight_id=flight.id, is_booked=is_booked)
        db.session.add(seat)
        db.session.commit()
        flash('Seat updated!', 'success')
    seats = Seat.query.filter_by(flight_id=flight.id).all()
    return render_template('admin_seats.html', flight=flight, seats=seats)

if __name__ == '__main__':
    app.run(debug=True, port=5001)
