from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///flyhigh.db'
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Models

@app.route('/book_and_ticket/<int:flight_id>', methods=['POST'])
@login_required
def book_and_ticket(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    seats = request.form['seats'].split(',')
    service_id = request.form.get('service_id')
    # Calculate total price
    total_amount = len(seats) * flight.price
    if service_id:
        service = Service.query.get(service_id)
        total_amount += service.price
    # Create booking
    booking = Booking(
        user_id=current_user.id,
        flight_id=flight_id,
        service_id=service_id,
        total_price=total_amount
    )
    db.session.add(booking)
    db.session.flush()  # Get booking ID without committing
    # Create seat records
    for seat_number in seats:
        seat = Seat(
            seat_number=seat_number,
            flight_id=flight_id,
            booking_id=booking.id,
            is_booked=True
        )
        db.session.add(seat)
    db.session.commit()
    return redirect(url_for('ticket_summary', booking_id=booking.id))

@app.route('/book_and_download/<int:flight_id>', methods=['POST'])
@login_required
def book_and_download(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    seats = request.form['seats'].split(',')
    service_id = request.form.get('service_id')
    # Calculate total price
    total_amount = len(seats) * flight.price
    selected_service = None
    if service_id:
        selected_service = Service.query.get(service_id)
        if selected_service:
            total_amount += selected_service.price
    # Create booking
    booking = Booking(
        user_id=current_user.id,
        flight_id=flight_id,
        service_id=service_id,
        total_price=total_amount
    )
    db.session.add(booking)
    db.session.flush()  # Get booking ID without committing
    # Create seat records
    for seat_number in seats:
        seat = Seat(
            seat_number=seat_number,
            flight_id=flight_id,
            booking_id=booking.id,
            is_booked=True
        )
        db.session.add(seat)
    db.session.commit()
    # Generate PDF Ticket
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50
    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width/2, y, "FlyHigh Airlines - Boarding Pass")
    y -= 40
    p.setFont("Helvetica-Bold", 12)
    p.drawString(50, y, "Passenger Details:")
    y -= 20
    p.setFont("Helvetica", 12)
    p.drawString(70, y, f"Username: {booking.user.username}")
    y -= 20
    if booking.user.email:
        p.drawString(70, y, f"Email: {booking.user.email}")
        y -= 20
    p.setFont("Helvetica-Bold", 12)
    p.drawString(50, y, "Flight Details:")
    y -= 20
    p.setFont("Helvetica", 12)
    p.drawString(70, y, f"Flight: {flight.name} ({flight.flight_number})")
    y -= 20
    p.drawString(70, y, f"From: {flight.origin}")
    y -= 20
    p.drawString(70, y, f"To: {flight.destination}")
    y -= 20
    p.drawString(70, y, f"Date: {flight.departure_time.strftime('%Y-%m-%d')}")
    y -= 20
    p.drawString(70, y, f"Time: {flight.departure_time.strftime('%H:%M')}")
    y -= 20
    p.setFont("Helvetica-Bold", 12)
    p.drawString(50, y, "Seat & Service Details:")
    y -= 20
    p.setFont("Helvetica", 12)
    seat_numbers = ', '.join([seat.seat_number for seat in booking.seats])
    p.drawString(70, y, f"Seats: {seat_numbers}")
    y -= 20
    if selected_service:
        p.drawString(70, y, f"Service Package: {selected_service.name} - {selected_service.description} (${selected_service.price:.2f})")
        y -= 20
    else:
        p.drawString(70, y, "Service Package: No package selected")
        y -= 20
    p.setFont("Helvetica-Bold", 12)
    p.drawString(50, y, "Cost Summary:")
    y -= 20
    p.setFont("Helvetica", 12)
    p.drawString(70, y, f"Base Price per Seat: ${flight.price:.2f}")
    y -= 20
    p.drawString(70, y, f"Number of Seats: {len(seats)}")
    y -= 20
    if selected_service:
        p.drawString(70, y, f"Service Price: ${selected_service.price:.2f}")
        y -= 20
    p.drawString(70, y, f"Total Amount: ${booking.total_price:.2f}")
    y -= 30
    p.setFont("Helvetica-Oblique", 10)
    p.drawString(50, y, "Thank you for booking with FlyHigh Airlines!")
    p.showPage()
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"FlyHigh_Ticket_{booking.id}.pdf", mimetype='application/pdf')

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)  # Made email nullable
    bookings = db.relationship('Booking', backref='user', lazy=True)

class Flight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    flight_number = db.Column(db.String(20), unique=True, nullable=False)
    origin = db.Column(db.String(100), nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    departure_time = db.Column(db.DateTime, nullable=False)
    duration = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    seats = db.relationship('Seat', backref='flight', lazy=True)
    services = db.relationship('Service', backref='flight', lazy=True)

class Seat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    seat_number = db.Column(db.String(10), nullable=False)
    is_booked = db.Column(db.Boolean, default=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'))

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)
    seats = db.relationship('Seat', backref='booking', lazy=True)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'))
    total_price = db.Column(db.Float, nullable=False)
    booking_time = db.Column(db.DateTime, default=datetime.utcnow)
    flight = db.relationship('Flight')
    service = db.relationship('Service')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def home():
    flights = Flight.query.all()
    return render_template('home.html', flights=flights)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and user.password == request.form['password']:
            login_user(user)
            return redirect(url_for('home'))
        flash('Invalid username or password')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form.get('email')  # email is now optional
        password = request.form['password']

        # Check if username exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('register'))
        
        # Check if email exists (only if email was provided)
        if email and User.query.filter_by(email=email).first():
            flash('Email already registered')
            return redirect(url_for('register'))
        
        user = User(username=username, password=password, email=email)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for('home'))
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/flight/<int:flight_id>')
@login_required
def flight_details(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    booked_seats = [seat.seat_number for seat in flight.seats if seat.is_booked]
    services = Service.query.filter_by(flight_id=flight_id).all()
    return render_template('flight_details.html', 
                         flight=flight, 
                         booked_seats=booked_seats,
                         services=services)

@app.route('/payment/<int:flight_id>', methods=['POST'])
@login_required
def payment(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    seats = request.form['seats'].split(',')
    service_id = request.form.get('service_id')
    
    # Calculate total price
    total_amount = len(seats) * flight.price
    if service_id:
        service = Service.query.get(service_id)
        total_amount += service.price

    # Create booking
    booking = Booking(
        user_id=current_user.id,
        flight_id=flight_id,
        service_id=service_id,
        total_price=total_amount
    )
    db.session.add(booking)
    db.session.flush()  # Get booking ID without committing

    # Create seat records
    for seat_number in seats:
        seat = Seat(
            seat_number=seat_number,
            flight_id=flight_id,
            booking_id=booking.id,
            is_booked=True
        )
        db.session.add(seat)

    db.session.commit()
    return render_template('payment.html', 
                         booking=booking,
                         total_amount=total_amount,
                         flight_id=flight_id,
                         seats=seats,
                         service_id=service_id)

@app.route('/confirm_booking/<int:flight_id>', methods=['POST'])
@login_required
def confirm_booking(flight_id):
    # Get the latest booking for this user and flight
    booking = Booking.query.filter_by(
        user_id=current_user.id,
        flight_id=flight_id
    ).order_by(Booking.booking_time.desc()).first()
    return redirect(url_for('ticket_summary', booking_id=booking.id))

@app.route('/ticket/<int:booking_id>')
@login_required
def ticket_summary(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    return render_template('ticket.html', booking=booking, booking_id=booking_id)

@app.route('/download_ticket/<int:booking_id>')
@login_required
def download_ticket(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50
    p.setFont("Helvetica-Bold", 18)
    p.drawCentredString(width/2, y, "FlyHigh Airlines - Boarding Pass")
    y -= 40
    p.setFont("Helvetica", 12)
    p.drawString(50, y, f"Passenger: {booking.user.username}")
    y -= 20
    p.drawString(50, y, f"Flight: {booking.flight.name} ({booking.flight.flight_number})")
    y -= 20
    p.drawString(50, y, f"From: {booking.flight.origin}")
    y -= 20
    p.drawString(50, y, f"To: {booking.flight.destination}")
    y -= 20
    p.drawString(50, y, f"Date: {booking.flight.departure_time.strftime('%Y-%m-%d')}")
    y -= 20
    p.drawString(50, y, f"Time: {booking.flight.departure_time.strftime('%H:%M')}")
    y -= 20
    seat_numbers = ', '.join([seat.seat_number for seat in booking.seats])
    p.drawString(50, y, f"Seats: {seat_numbers}")
    y -= 20
    service = booking.service.name if booking.service else 'No package selected'
    p.drawString(50, y, f"Service Package: {service}")
    y -= 20
    p.drawString(50, y, f"Total Amount: ${booking.total_price:.2f}")
    p.showPage()
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f"FlyHigh_Ticket_{booking.id}.pdf", mimetype='application/pdf')

    p.setFont('Helvetica-Bold', 18)
    p.drawString(200, 750, 'FlyHigh Airlines')
    p.setFont('Helvetica', 14)
    p.drawString(220, 720, 'Boarding Pass')
    p.setFont('Helvetica', 12)
    y = 680
    p.drawString(50, y, f"Passenger: {booking.user.username}")
    p.drawString(50, y-20, f"Flight: {booking.flight.name}")
    p.drawString(50, y-40, f"Flight Number: {booking.flight.flight_number}")
    p.drawString(50, y-60, f"From: {booking.flight.origin}")
    p.drawString(50, y-80, f"To: {booking.flight.destination}")
    p.drawString(50, y-100, f"Date: {booking.flight.departure_time.strftime('%Y-%m-%d')}")
    p.drawString(50, y-120, f"Time: {booking.flight.departure_time.strftime('%H:%M')}")
    # Show all seat numbers booked
    seat_numbers = ', '.join([seat.seat_number for seat in booking.seats])
    p.drawString(50, y-140, f"Seat(s): {seat_numbers}")
    p.drawString(50, y-160, f"Service Package: {booking.service.name if booking.service else 'No package selected'}")
    p.drawString(50, y-180, f"Total Amount: ${booking.total_price:.2f}")
    p.showPage()
    p.save()
    buffer.seek(0)
    return send_file(buffer, as_attachment=True, download_name=f'FlyHigh_Ticket_{booking.id}.pdf', mimetype='application/pdf')

from flask import send_file
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

if __name__ == '__main__':
    app.run(debug=True)
