from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime
import os
import qrcode
from io import BytesIO

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///flyhigh.db'
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    bookings = db.relationship('Booking', backref='user', lazy=True)

class Flight(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    flight_number = db.Column(db.String(10), unique=True)
    name = db.Column(db.String(100))
    origin = db.Column(db.String(100))
    destination = db.Column(db.String(100))
    departure_time = db.Column(db.DateTime)
    arrival_time = db.Column(db.DateTime)
    duration = db.Column(db.String(20))
    price = db.Column(db.Float)
    total_seats = db.Column(db.Integer)
    booked_seats = db.relationship('Seat', backref='flight', lazy=True)
    services = db.relationship('Service', backref='flight', lazy=True)

class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)

class Seat(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)
    seat_number = db.Column(db.String(10), nullable=False)
    is_booked = db.Column(db.Boolean, default=False)
    booking_id = db.Column(db.Integer, db.ForeignKey('booking.id'), nullable=True)

class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.id'), nullable=False)
    seat = db.relationship('Seat', backref='booking', uselist=False)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=True)
    booking_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    total_price = db.Column(db.Float, nullable=False)
    payment_status = db.Column(db.String(20), default='pending')
    ticket_downloaded = db.Column(db.Boolean, default=False)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        
        # Check if email already exists
        if User.query.filter_by(email=email).first():
            flash('Email already registered. Please use a different email or login.')
            return redirect(url_for('register'))
        
        # Check if username already exists
        if User.query.filter_by(username=username).first():
            flash('Username already taken. Please choose a different username.')
            return redirect(url_for('register'))
        
        user = User(username=username, email=email, password=password)
        try:
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please login.')
            return redirect(url_for('login'))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred during registration. Please try again.')
            return redirect(url_for('register'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        
        if user and user.password == password:
            login_user(user)
            return redirect(url_for('home'))
        else:
            flash('Invalid username or password')
    
    return render_template('login.html')

@app.route('/home')
@login_required
def home():
    flights = Flight.query.all()
    return render_template('home.html', flights=flights)

@app.route('/flight/<int:flight_id>')
@login_required
def flight_details(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    available_seats = [seat for seat in flight.booked_seats if not seat.is_booked]
    return render_template('flight_details.html', flight=flight, available_seats=available_seats)

@app.route('/book/<int:flight_id>', methods=['POST'])
@login_required
def book_flight(flight_id):
    flight = Flight.query.get_or_404(flight_id)
    seat_id = request.form.get('seat_id')
    service_id = request.form.get('service_id')
    
    seat = Seat.query.get_or_404(seat_id)
    service = Service.query.get(service_id) if service_id else None
    
    total_price = flight.price
    if service:
        total_price += service.price
    
    booking = Booking(
        user_id=current_user.id,
        flight_id=flight_id,
        service_id=service_id,
        total_price=total_price
    )
    
    db.session.add(booking)
    seat.is_booked = True
    seat.booking_id = booking.id
    db.session.commit()
    
    return redirect(url_for('payment', booking_id=booking.id))

@app.route('/payment/<int:booking_id>')
@login_required
def payment(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    # Generate QR code for payment
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(f"FlyHigh Payment - Booking ID: {booking.id} - Amount: ${booking.total_price}")
    qr.make(fit=True)
    qr_image = qr.make_image(fill_color="black", back_color="white")
    
    # Save QR code to BytesIO
    img_io = BytesIO()
    qr_image.save(img_io, 'PNG')
    img_io.seek(0)
    
    return render_template('payment.html', booking=booking, qr_code=img_io.getvalue())

@app.route('/confirm_payment/<int:booking_id>')
@login_required
def confirm_payment(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    booking.payment_status = 'completed'
    db.session.commit()
    return redirect(url_for('ticket', booking_id=booking.id))

@app.route('/ticket/<int:booking_id>')
@login_required
def ticket(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    return render_template('ticket.html', booking=booking)

@app.route('/download_ticket/<int:booking_id>')
@login_required
def download_ticket(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    # Generate ticket PDF logic here
    booking.ticket_downloaded = True
    db.session.commit()
    return redirect(url_for('ticket', booking_id=booking.id))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
