import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flyhigh import app, db, Flight, Service, Seat
from datetime import datetime, timedelta

def init_db():
    with app.app_context():
        # Drop and recreate tables
        db.drop_all()
        db.create_all()
        
        # Create flights
        flights = [
            Flight(
                name='Morning Express',
                flight_number='FH101',
                origin='New York',
                destination='Los Angeles',
                departure_time=datetime.now() + timedelta(days=1),
                duration='6 hours',
                price=299.99
            ),
            Flight(
                name='Afternoon Delight',
                flight_number='FH102',
                origin='Chicago',
                destination='Miami',
                departure_time=datetime.now() + timedelta(days=2),
                duration='3 hours',
                price=199.99
            ),
            Flight(
                name='Evening Star',
                flight_number='FH103',
                origin='San Francisco',
                destination='Seattle',
                departure_time=datetime.now() + timedelta(days=1),
                duration='2 hours',
                price=149.99
            )
        ]
        
        for flight in flights:
            db.session.add(flight)
        db.session.commit()

        # Create seats for each flight (10 rows x 6 seats = 60 seats per flight)
        for flight in flights:
            for row in range(1, 11):  # 10 rows
                for col in ['A', 'B', 'C', 'D', 'E', 'F']:  # 6 seats per row
                    seat = Seat(
                        seat_number=f"{row}{col}",
                        flight_id=flight.id,
                        is_booked=False  # All seats start as available
                    )
                    db.session.add(seat)

        # Create food & beverage services for each flight
        services = [
            {
                'name': 'Basic Package',
                'description': 'Water, sandwich, and snacks',
                'price': 15.99
            },
            {
                'name': 'Premium Package',
                'description': 'Hot meal, drinks, and premium snacks',
                'price': 29.99
            },
            {
                'name': 'Deluxe Package',
                'description': 'Gourmet meal, alcoholic beverages, and luxury snacks',
                'price': 49.99
            }
        ]

        for flight in flights:
            for service_data in services:
                service = Service(
                    name=service_data['name'],
                    description=service_data['description'],
                    price=service_data['price'],
                    flight_id=flight.id
                )
                db.session.add(service)

        db.session.commit()
        print("Database initialized successfully!")

if __name__ == '__main__':
    init_db()
